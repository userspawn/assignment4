#ifndef BINARYDATASET_HPP_
#define BINARYDATASET_HPP_

#define MAX_OBSERVATIONS 10000
#define MAX_NUM_FEATURES 10000

class BinaryDataset {
public:
// Constructors and deconstructors
  BinaryDataset();
  BinaryDataset(const char *, unsigned int);
  virtual ~BinaryDataset();

// Getters and setters
  void setNumFeatures(unsigned int);
  unsigned int getNumFeatures();
  void getObservation(unsigned int, double *);
  void setObservation(unsigned int, double *);
  void setLabel(unsigned int, int);
  int getLabel(unsigned int);
  unsigned int getNumObservations();
  void setNumObservations(unsigned int);

// Other methods
  void print();
  void split(unsigned int, unsigned int, BinaryDataset *, BinaryDataset *);
  void splitLOO(unsigned int, BinaryDataset *, BinaryDataset *);
  void findOptimalSplit(unsigned int *, unsigned int *); 
  double calcImpurityEntropy();
  int getMajorityLabel();
  bool isEmpty();
  void appendObservation(double *, int);
  unsigned int CountLabels();
  void zero();
  double calcImpurityDrop(BinaryDataset *subset1, BinaryDataset *subset2);

  //variables
  double dataset[MAX_OBSERVATIONS][MAX_NUM_FEATURES];
  unsigned int numFeatures;
  unsigned int numObservations;
};

#endif /* BINARYDATASET_HPP_ */
