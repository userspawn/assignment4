#include "BinaryDecisionTree.hpp"

BinaryDecisionTree::BinaryDecisionTree() { 
  // TODO IMPLEMENT //
}

BinaryDecisionTree::BinaryDecisionTree(BinaryDataset *dataset) { 
 // TODO IMPLEMENT //
}

BinaryDecisionTree::~BinaryDecisionTree() { 
  // TODO IMPLEMENT //
}

void BinaryDecisionTree::print() {
  // TODO IMPLEMENT // 
}

void BinaryDecisionTree::print(BinaryNode *node_in) { 
  // TODO IMPLEMENT //
}

BinaryNode * BinaryDecisionTree::getRoot() {
  // TODO IMPLEMENT //
  return nullptr;
}

int BinaryDecisionTree::classify(double *ft_in) {
  // TODO IMPLEMENT //
  return 0;
}

void BinaryDecisionTree::growTree(BinaryDataset *dataset_in, BinaryNode *node_in) {
  // TODO IMPLEMENT //
}


void BinaryDecisionTree::deleteSubtree(BinaryNode *node_in) {
  // TODO IMPLEMENT //
}

unsigned int BinaryDecisionTree::size() { 
  // TODO IMPLEMENT //
  return 0.0;
}

unsigned int BinaryDecisionTree::leafCount(BinaryNode *node_in) {
  // TODO IMPLEMENT //
  return 0.0;
}

void BinaryDecisionTree::setRoot(BinaryNode *node_in){
  // TODO IMPLEMENT //
}


