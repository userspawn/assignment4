#include "BinaryNode.hpp"
#include <iostream>
using namespace std;

BinaryNode::BinaryNode() {
  nodeY = {nullptr};
  nodeN = {nullptr};
  decisionDimension = 1;
  decisionCriterion = 1;
  impurity = -1;
  label = 0;
}

BinaryNode::~BinaryNode() {
  // TODO IMPLEMENT // 
}

bool BinaryNode::isLeaf() {
  if (this->getNodeY() == nullptr && this->getNodeN() == nullptr) {
    return true;
  }
  return false;
}

// Getters and setters
BinaryNode * BinaryNode::getNodeY() {
  return nodeY;
}

BinaryNode * BinaryNode::getNodeN() {
  return nodeN;
}

void BinaryNode::setNodeY(BinaryNode *node_in) {
  nodeY = node_in;
}

void BinaryNode::setNodeN(BinaryNode *node_in) {
  nodeN = node_in;
}

void BinaryNode::setDecisionDim(unsigned int dim_in) {
  decisionDimension = dim_in;
}

unsigned int BinaryNode::getDecisionDim() {
  return decisionDimension;
}

void BinaryNode::setDecisionCriterion(double criterion_in) {
  decisionCriterion = criterion_in;
}

double BinaryNode::getDecisionCriterion() {
  return decisionCriterion;
}

void BinaryNode::setLabel(int label_in) {
  label = label_in;
}

int BinaryNode::getLabel() {
  return label;
}

void BinaryNode::setImpurity(double impurity_in) {
  impurity = impurity_in;
}

double BinaryNode::getImpurity() {
  return impurity;
}

