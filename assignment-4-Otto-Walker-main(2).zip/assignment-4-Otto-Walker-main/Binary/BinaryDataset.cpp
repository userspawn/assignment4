#include "BinaryDataset.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

BinaryDataset::BinaryDataset() { 
  numFeatures = 0;
  numObservations = 0;
}

BinaryDataset::BinaryDataset(const char *filename_in, unsigned int num_features) {
  numFeatures = num_features;
  numObservations = 0;
  unsigned int i = 0;
  unsigned int j = 0;
  fstream fs_filename_in(filename_in, std::ios_base::in);
  while (fs_filename_in >> dataset[i][j]) {
    j++;
    if (j == numFeatures + 1) {
      i++;
      j = 0;
      numObservations++;
    }
  }
}

unsigned int BinaryDataset::CountLabels() { // returns amount of observations with label 1
  int amountOnes = 0;
  for (unsigned int i = 0; i < numObservations; i++) {
    if (dataset[i][numFeatures] == 1) {
      amountOnes++;
    }
  }
  return amountOnes;
}

BinaryDataset::~BinaryDataset() { 
  // TODO IMPLEMENT //
}

bool BinaryDataset::isEmpty() {
  if (!numObservations) {
    return true;  
  }
  return false;
}

int BinaryDataset::getMajorityLabel() { 
  if (this->CountLabels() > this->getNumObservations()) {
    return 1;
  } else {
    return 0;
  }
}

double BinaryDataset::calcImpurityEntropy() {
  double n = this->getNumObservations();
  double n2 = this->CountLabels();
  double n1 = n - n2;
  if (n1 == 0 || n2 == 0) {
    return 0;
  }
  return (-n1 / n) * log2(n1 / n) - (n2 / n) * log2(n2 / n);
}

void BinaryDataset::print() {
  for (unsigned int i = 0; i < numObservations; i++) {
    for (unsigned int j = 0; j < numFeatures + 1; j++) {
      cout << dataset[i][j] << ", ";
    }
    cout << endl;
  }
}

void BinaryDataset::split(unsigned int iidim, unsigned int iiobs, BinaryDataset *subset1, BinaryDataset *subset2) {
  subset2->setNumFeatures(this->numFeatures);
  subset1->setNumFeatures(this->numFeatures);
  double set[numFeatures];
  for (unsigned int i = 0; i < numObservations; i++) {
    if (this->dataset[i][iidim] < this->dataset[iiobs][iidim]) {
      this->getObservation(i, set);
      int label = this->getLabel(i);
      subset1->appendObservation(set, label);
    } else {
      this->getObservation(i, set);
      int label = this->getLabel(i);
      subset2->appendObservation(set, label);
    }
  }
}

void BinaryDataset::appendObservation(double *ft_in, int label_in) {
    this->setObservation(numObservations, ft_in);
    this->setLabel(numObservations, label_in);
    numObservations++;
}

void BinaryDataset::splitLOO(unsigned int ii, BinaryDataset *dataset1, BinaryDataset *dataset2) {
  dataset2->setNumFeatures(this->numFeatures);
  dataset1->setNumFeatures(this->numFeatures);
  double set[numFeatures];
  for (unsigned int i = 0; i < this->numObservations; i++) {
    if (i == ii - 1) {
      this->getObservation(i, set);
      int label = this->getLabel(i);
      dataset2->appendObservation(set, label);
    } else {
      this->getObservation(i, set);
      int label = this->getLabel(i);
      dataset1->appendObservation(set, label);
    }
  }
}

void BinaryDataset::findOptimalSplit(unsigned int *out_dim, unsigned int *out_ii) {
  double current = 0;
  BinaryDataset* subset1 = new BinaryDataset();
  BinaryDataset* subset2 = new BinaryDataset();
  subset1->setNumFeatures(this->numFeatures);
  subset2->setNumFeatures(this->numFeatures);
  unsigned int outdim;
  unsigned int outii;
  for (unsigned int i = 0; i < numObservations; i++) {
    for (unsigned int j = 0; j < numFeatures; j++) {
      this->split(i, j, subset1, subset2);
      if (calcImpurityDrop(subset1, subset2) > current) {
        current = calcImpurityDrop(subset1, subset2);
        outdim = j;
        outii = i;
      }
    }
  }
  //cout << outdim << endl;
  //cout << outii << endl;
  *out_dim = outdim;
  *out_ii = outii;
}

double BinaryDataset::calcImpurityDrop(BinaryDataset *subset1, BinaryDataset *subset2) {
  double ied = this->calcImpurityEntropy();
  double n = double(this->getNumObservations());
  double n1 = double(subset1->getNumObservations());
  double n2 = double(subset2->getNumObservations());
  double ied1 = subset1->calcImpurityEntropy();
  double ied2 = subset2->calcImpurityEntropy();
  return ied - (n1 / n) * ied1 - (1 - (n2 / n) * ied2);
}

void BinaryDataset::getObservation(unsigned int ix, double *features) {
  for (unsigned int i = 0; i < numFeatures; i++) {
    features[i] = dataset[ix][i];
  }
}

void BinaryDataset::setObservation(unsigned int ix, double *features) {
  for (unsigned int i = 0; i < numFeatures; i++) {
    dataset[ix][i] = features[i];
  }
}

void BinaryDataset::setLabel(unsigned int ix, int label_in) {
  dataset[ix][numFeatures] = label_in;
}

int BinaryDataset::getLabel(unsigned int ix) {
  return int(dataset[ix][numFeatures]);
}

void BinaryDataset::setNumFeatures(unsigned int num_features_in){
  numFeatures = num_features_in;
}

unsigned int BinaryDataset::getNumFeatures(){
  return numFeatures;
}

unsigned int BinaryDataset::getNumObservations(){
  return numObservations;
}

void BinaryDataset::setNumObservations(unsigned int num_observations_in){
  numObservations = num_observations_in;
}

void BinaryDataset::zero() {
  numObservations = 0;
}
